export const citiesArray = [
    { name: "Ашхабад", value: "Ag" },
    { name: "Ахал", value: "Ah" },
    { name: "Балканы", value: "Bl" },
    { name: "Мары", value: "Mr" },
    { name: "Дашогуз", value: "Dz" },
    { name: "Лебап", value: "Lb" },
];
