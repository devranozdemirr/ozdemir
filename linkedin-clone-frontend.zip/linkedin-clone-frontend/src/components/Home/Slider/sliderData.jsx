export const items = [
    {
        className: "img-fluid",
        src: "https://wallpaperaccess.com/full/32819.jpg",
        alt: "Slider-2",
        link: "/",
    },
    {
        className: "img-fluid",
        src: "https://gnbookstore.com.tm/storage/s/koxQi14gLR.jpg",
        alt: "Slider-3",
        link: "/login",
    },
    {
        className: "img-fluid",
        src: "https://wallpapercave.com/wp/wp6916155.jpg",
        alt: "Slider-1",
        link: "/signup",
    },
];
