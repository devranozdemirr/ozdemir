import React from "react";

function LoadingSlider() {
    return (
        <div class="imageSk">
            <div class="imageSkImg"></div>
        </div>
    );
}

export default LoadingSlider;
