export const works = [
	{ name: "First" },
	{ name: "Second" },
	{ name: "Third" },
	{ name: "Fourth" },
	{ name: "Fifth" },
	{ name: "Sixth" },
	{ name: "Seventh" },
	{ name: "Eigth" },
	{ name: "Nineth" },
	{ name: "Tenth" },
];
