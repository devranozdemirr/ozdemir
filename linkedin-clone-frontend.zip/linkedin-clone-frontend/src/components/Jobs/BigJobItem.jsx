import React from "react";

function BigJobItem() {
    return <div>BIg item</div>;
}

export default BigJobItem;
