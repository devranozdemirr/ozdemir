CITIES = (
    ('Ag', 'Ashgabat'),
    ('Ah', 'Ahal'),
    ('Bl', 'Balkan'),
    ('Mr', 'Mary'),
    ('Dz', 'Dasoguz'),
    ('Lb', 'Lebap'),
)


SHORT_CITIES = [
    "Ag", "Ah", "Bl", "Mr", "Dz", "Lb"
]
